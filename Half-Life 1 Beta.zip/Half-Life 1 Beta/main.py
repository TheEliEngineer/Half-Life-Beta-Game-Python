from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController

app = Ursina()

# --- Sound ---
footstep_sound = Audio('sounds/pl_tile2.wav', autoplay=False)
footstep_timer = 0

# --- Sky and Lighting ---
Sky()
DirectionalLight().look_at(Vec3(1, -1, -1))

# --- Ground ---
ground = Entity(
    model='plane',
    scale=100,
    texture='textures/grass.png',
    texture_scale=(50, 50),
    collider='box'
)

# --- Player ---
player = FirstPersonController()
player.gravity = 0.5
player.speed = 5

# --- Barney NPC ---
barney = Entity(
    model='models/barney.glb',
    position=(5, 0, 5),
    scale=1,
    collider='box',
    color=color.white
)
barney_dir = 1

# --- Scientist NPC ---
scientist = Entity(
    model='models/scientist.glb',
    position=(8, 0, 5),
    scale=1,
    collider='box',
    color=color.white
)
scientist_dir = -1

# --- Update Logic ---
def update():
    global footstep_timer, barney_dir, scientist_dir

    # Footsteps
    is_moving = held_keys['w'] or held_keys['a'] or held_keys['s'] or held_keys['d']
    if is_moving and player.grounded:
        footstep_timer -= time.dt
        if footstep_timer <= 0:
            footstep_sound.play()
            footstep_timer = 0.5
    else:
        footstep_timer = 0

    # NPC movement: Barney paces on X axis
    barney.x += 1 * time.dt * barney_dir
    if barney.x > 7 or barney.x < 3:
        barney_dir *= -1
        barney.rotation_y += 180

    # NPC movement: Scientist paces on Z axis
    scientist.z += 1 * time.dt * scientist_dir
    if scientist.z > 7 or scientist.z < 3:
        scientist_dir *= -1
        scientist.rotation_y += 180

app.run()

